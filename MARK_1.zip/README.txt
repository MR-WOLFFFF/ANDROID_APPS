HELLOCARAPP - STRUCTURED ANDROID AUTO PROJECT

Structure:
- automotive  -> Android Auto / car application module
- mobile      -> simple phone app showing HELLO RAJ
- shared      -> CarAppService, session, screen, automotive XML metadata

What it does:
- Automotive app shows HELLO RAJ using a car template
- Mobile app shows HELLO RAJ on the phone

How to use:
1. Extract ZIP
2. Open folder in Android Studio
3. Use JDK 17 if Android Studio asks
4. Let Gradle sync
5. Build the automotive module APK for Android Auto
6. Install on phone
7. Connect phone to car and open Android Auto

Notes:
- This is a structured sample based on the Empty Car App Library style
- local.properties is not included because SDK paths differ by machine
