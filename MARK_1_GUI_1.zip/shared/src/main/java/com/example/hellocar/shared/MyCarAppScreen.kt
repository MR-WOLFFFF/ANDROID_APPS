package com.example.hellocar.shared

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template

class MyCarAppScreen(carContext: CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        val pane = Pane.Builder()
            .addRow(
                Row.Builder()
                    .setTitle("HELLO RAJ")
                    .build()
            )
            .build()

        return PaneTemplate.Builder(pane)
            .setTitle("MARK_1_GUI_1")
            .build()
    }
}
