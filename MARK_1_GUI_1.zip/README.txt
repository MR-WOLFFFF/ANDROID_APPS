MARK_1_GUI_1

Fix applied:
- Removed icon references that caused:
  resource mipmap/ic_launcher not found

Project structure:
- automotive
- mobile
- shared

What to build:
- Android Auto app: build automotive
- Phone preview app: build mobile

If Android Studio asks for:
- SDK path -> set Android SDK folder
- JDK -> use JDK 17
