#!/usr/bin/env python3
"""
Raspberry Pi server.
Receives "1" or "0" from laptop over TCP through USB gadget Ethernet link.
"""

import socket

HOST = "10.55.0.2"
PORT = 5000

def handle_message(message: str) -> str:
    message = message.strip()
    if message == "1":
        print("Received 1 -> signal detected")
        return "ACK:1"
    elif message == "0":
        print("Received 0 -> signal detected")
        return "ACK:0"
    else:
        print(f"Invalid data received: {message!r}")
        return "ERR:INVALID"

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind((HOST, PORT))
        server.listen(5)
        print(f"Listening on {HOST}:{PORT}")

        while True:
            conn, addr = server.accept()
            with conn:
                print(f"Connected by {addr}")
                data = conn.recv(1024)
                if not data:
                    continue
                message = data.decode("utf-8").strip()
                reply = handle_message(message)
                conn.sendall((reply + "\n").encode("utf-8"))

if __name__ == "__main__":
    main()
