```mermaid
flowchart LR
    A[Laptop / PC<br/>Python client or GUI] -->|USB cable| B[USB Gadget Ethernet link]
    B -->|TCP message: "1" or "0"| C[Raspberry Pi<br/>Python server]
    C --> D[Print ACK / future GPIO action]
```
