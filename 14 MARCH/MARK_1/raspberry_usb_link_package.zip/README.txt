# Raspberry Pi package

## Aim
Raspberry Pi waits for `"1"` or `"0"` from laptop over USB and confirms reception.

## Protocol used
- **Physical link:** USB cable
- **USB mode:** **USB Gadget Ethernet**
- **Transport:** **TCP**
- **Data format:** text message `"1"` or `"0"`

## Files
- `pi_server.py` → Python TCP server

## Raspberry Pi IP setup
USB gadget interface should use:
- IP: `10.55.0.2`
- Mask: `255.255.255.0`

Laptop side should use:
- IP: `10.55.0.1`

## Run in Thonny
1. Open `pi_server.py`
2. Click **Run**

## Run in terminal
```bash
python3 pi_server.py
```

## Test
After the server starts, go to laptop and send:
```bash
python laptop_client.py 1
```
or
```bash
python laptop_client.py 0
```

## Expected terminal output on Pi
- `Received 1 -> signal detected`
- `Received 0 -> signal detected`

## Important hardware note
This package assumes you enable **USB Gadget Ethernet** on Raspberry Pi first.
On recent Raspberry Pi OS versions, this can be enabled with the official `rpi-usb-gadget` setup.
