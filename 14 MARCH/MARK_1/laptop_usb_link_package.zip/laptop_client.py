#!/usr/bin/env python3
"""
Laptop-side client.
Sends "1" or "0" to Raspberry Pi over TCP through the USB gadget Ethernet link.
"""

import socket
import sys

PI_IP = "10.55.0.2"
PI_PORT = 5000

def send_value(value: str) -> str:
    if value not in {"0", "1"}:
        raise ValueError("Only '0' or '1' are allowed.")

    with socket.create_connection((PI_IP, PI_PORT), timeout=5) as sock:
        sock.sendall((value + "\n").encode("utf-8"))
        reply = sock.recv(1024).decode("utf-8").strip()
        return reply

def main():
    if len(sys.argv) != 2:
        print("Usage: python laptop_client.py 1")
        print("       python laptop_client.py 0")
        sys.exit(1)

    value = sys.argv[1]
    try:
        reply = send_value(value)
        print(f"Raspberry Pi reply: {reply}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(2)

if __name__ == "__main__":
    main()
