# Laptop package

## Aim
Send `"1"` or `"0"` from your laptop to Raspberry Pi through a **USB cable**.

## Protocol used
- **Physical link:** USB cable
- **USB function:** **USB Gadget Ethernet** on Raspberry Pi
- **Network layer:** Static IP over USB
- **Application layer:** **TCP socket**
- **Payload:** ASCII text `"1"` or `"0"`

This is not raw USB bit banging.  
It is a **USB virtual Ethernet link**, then Python sends TCP messages through that link.

## Files
- `laptop_client.py` → command-line sender
- `laptop_gui.py` → simple button GUI

## Laptop IP setup
Set your laptop USB-Ethernet adapter to:
- IP: `10.55.0.1`
- Mask: `255.255.255.0`

Raspberry Pi side uses:
- IP: `10.55.0.2`
- Port: `5000`

## Run
### Option 1: command line
```bash
python laptop_client.py 1
python laptop_client.py 0
```

### Option 2: GUI
```bash
python laptop_gui.py
```

## Expected replies
- Send `1` → Pi replies `ACK:1`
- Send `0` → Pi replies `ACK:0`

## Important note about Google Colab
Google Colab is **not recommended** for this USB-direct setup because Colab runs in the cloud.
Use **VS Code / local Python / Jupyter on your own laptop**.
