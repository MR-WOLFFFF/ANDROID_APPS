#!/usr/bin/env python3
"""
Laptop-side GUI.
Two buttons send 1 or 0 to Raspberry Pi and show the reply.
"""

import socket
import tkinter as tk
from tkinter import messagebox

PI_IP = "10.55.0.2"
PI_PORT = 5000

def send_value(value: str):
    try:
        with socket.create_connection((PI_IP, PI_PORT), timeout=5) as sock:
            sock.sendall((value + "\n").encode("utf-8"))
            reply = sock.recv(1024).decode("utf-8").strip()
            status_var.set(f"Sent: {value} | Reply: {reply}")
    except Exception as e:
        messagebox.showerror("Connection error", str(e))
        status_var.set("Connection failed")

root = tk.Tk()
root.title("Laptop -> Raspberry Pi USB Link")

frame = tk.Frame(root, padx=20, pady=20)
frame.pack()

tk.Label(frame, text="Send digital value to Raspberry Pi", font=("Arial", 12, "bold")).pack(pady=(0, 10))

btn_frame = tk.Frame(frame)
btn_frame.pack(pady=5)

tk.Button(btn_frame, text="Send 1", width=12, command=lambda: send_value("1")).grid(row=0, column=0, padx=5)
tk.Button(btn_frame, text="Send 0", width=12, command=lambda: send_value("0")).grid(row=0, column=1, padx=5)

status_var = tk.StringVar(value="Not connected yet")
tk.Label(frame, textvariable=status_var, wraplength=350).pack(pady=(10, 0))

root.mainloop()
