package com.example.mark_2_mqtt

import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.MqttCallback
import org.eclipse.paho.client.mqttv3.MqttClient
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttException
import org.eclipse.paho.client.mqttv3.MqttMessage
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var indicatorView: View
    private lateinit var statusText: TextView
    private lateinit var sendButton: Button

    private val executor = Executors.newSingleThreadExecutor()
    private var mqttClient: MqttClient? = null

    private val broker = "tcp://broker.hivemq.com:1883"
    private val publishTopic = "mark2/mqtt/android_to_pi"
    private val subscribeTopic = "mark2/mqtt/pi_to_android"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        indicatorView = findViewById(R.id.indicatorView)
        statusText = findViewById(R.id.statusText)
        sendButton = findViewById(R.id.sendButton)

        setIndicator(false)
        connectMqtt()

        sendButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    publishValue("1")
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    publishValue("0")
                    true
                }
                else -> false
            }
        }
    }

    private fun connectMqtt() {
        executor.execute {
            try {
                val clientId = "android-" + UUID.randomUUID().toString().take(8)
                mqttClient = MqttClient(broker, clientId, null)

                val options = MqttConnectOptions().apply {
                    isAutomaticReconnect = true
                    isCleanSession = true
                    connectionTimeout = 10
                    keepAliveInterval = 20
                }

                mqttClient?.setCallback(object : MqttCallback {
                    override fun connectionLost(cause: Throwable?) {
                        runOnUiThread {
                            statusText.text = "Receiver: disconnected"
                            setIndicator(false)
                        }
                    }

                    override fun messageArrived(topic: String?, message: MqttMessage?) {
                        val value = message?.payload?.toString(StandardCharsets.UTF_8)?.trim() ?: "0"
                        runOnUiThread {
                            if (value == "1") {
                                statusText.text = "Receiver: 1"
                                setIndicator(true)
                            } else {
                                statusText.text = "Receiver: 0"
                                setIndicator(false)
                            }
                        }
                    }

                    override fun deliveryComplete(token: IMqttDeliveryToken?) {
                    }
                })

                mqttClient?.connect(options)
                mqttClient?.subscribe(subscribeTopic)

                runOnUiThread {
                    statusText.text = "Receiver: connected"
                }
            } catch (e: MqttException) {
                runOnUiThread {
                    statusText.text = "Receiver: connection error"
                    setIndicator(false)
                }
            }
        }
    }

    private fun publishValue(value: String) {
        executor.execute {
            try {
                if (mqttClient?.isConnected != true) return@execute
                val message = MqttMessage(value.toByteArray(StandardCharsets.UTF_8)).apply {
                    qos = 0
                    isRetained = false
                }
                mqttClient?.publish(publishTopic, message)
            } catch (_: Exception) {
            }
        }
    }

    private fun setIndicator(isGreen: Boolean) {
        val drawableId = if (isGreen) R.drawable.bg_indicator_green else R.drawable.bg_indicator_red
        indicatorView.setBackgroundResource(drawableId)
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.execute {
            try {
                mqttClient?.disconnect()
                mqttClient?.close()
            } catch (_: Exception) {
            }
        }
        executor.shutdownNow()
    }
}
