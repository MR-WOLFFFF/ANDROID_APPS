MARK_2_MQTT ANDROID APP

Purpose:
- Press and hold button -> sends "1" to Raspberry Pi over MQTT
- Release button -> sends "0" to Raspberry Pi over MQTT
- Receives "1" from Raspberry Pi -> indicator turns green
- Receives "0" from Raspberry Pi -> indicator turns red

MQTT topics:
- Android publishes to: mark2/mqtt/android_to_pi
- Android subscribes to: mark2/mqtt/pi_to_android

Broker:
- broker.hivemq.com
- Port 1883

Open in Android Studio:
1. Extract ZIP
2. Open project folder
3. Use JDK 17 if Android Studio asks
4. Build APK(s)

Note:
- local.properties is not included because SDK paths differ by machine
