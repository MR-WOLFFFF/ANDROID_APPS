MARK_2_MQTT_FIXED ANDROID APP

Fixes:
- drawable resources moved to real drawable XML files
- safer MQTT client setup with MemoryPersistence
- added ACCESS_NETWORK_STATE and usesCleartextTraffic
- simpler startup path

MQTT topics:
- Android publishes to: mark2/mqtt/android_to_pi
- Android subscribes to: mark2/mqtt/pi_to_android

Broker:
- broker.hivemq.com
- Port 1883
