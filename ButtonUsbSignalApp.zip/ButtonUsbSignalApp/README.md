# Button USB Signal App

This Android app is designed for a **USB-tethering-based** connection between an Android phone and a Raspberry Pi 5.

## What it does
- Shows a status block: `OK` when the signal is sent successfully, otherwise `0`
- Sends JSON `{ "value": 1 }` to the Raspberry Pi when the button is pressed

## Important note
A Raspberry Pi 5 does **not** normally behave like a simple USB peripheral for a phone over a direct raw USB-app link. The practical approach is:
1. Connect phone to Pi with USB cable
2. Enable **USB tethering** on the phone
3. Run the Python receiver on the Pi
4. Set the Pi receiver IP in `MainActivity.kt`
5. Build and install the app

## Build
Open this folder in Android Studio and build the APK.
