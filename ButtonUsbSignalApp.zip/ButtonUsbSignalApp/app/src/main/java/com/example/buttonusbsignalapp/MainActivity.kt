package com.example.buttonusbsignalapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.buttonusbsignalapp.databinding.ActivityMainBinding
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val client = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(2, TimeUnit.SECONDS)
        .writeTimeout(2, TimeUnit.SECONDS)
        .build()

    // Change this if your Raspberry Pi gets a different IP on USB tethering.
    // Example often used in USB tethering: 192.168.42.129
    private val serverUrl = "http://192.168.42.129:5000/signal"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.statusText.text = "0"
        binding.infoText.text = "Tap button to send 1 to Raspberry Pi"

        binding.sendButton.setOnClickListener {
            sendSignalToPi(1)
        }
    }

    private fun sendSignalToPi(value: Int) {
        binding.sendButton.isEnabled = false
        binding.infoText.text = "Sending..."

        Thread {
            val json = "{\"value\":$value}"
            val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(serverUrl)
                .post(body)
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    runOnUiThread {
                        binding.sendButton.isEnabled = true
                        if (response.isSuccessful) {
                            binding.statusText.text = "OK"
                            binding.infoText.text = "Signal 1 sent to Raspberry Pi"
                        } else {
                            binding.statusText.text = "0"
                            binding.infoText.text = "Server error: ${response.code}"
                        }
                    }
                }
            } catch (e: IOException) {
                runOnUiThread {
                    binding.sendButton.isEnabled = true
                    binding.statusText.text = "0"
                    binding.infoText.text = "Connection failed. Check USB tethering and Pi IP."
                }
            }
        }.start()
    }
}
