# Phone ↔ Raspberry Pi 5 USB Demo Package

This package contains two deliverables:

1. **ButtonUsbSignalApp**
   - Android Studio project
   - One button
   - Status text shows `OK` on success, otherwise `0`
   - Sends signal `1` to Raspberry Pi

2. **raspberry_pi_receiver**
   - Python GUI program for Raspberry Pi 5
   - Shows `RECEIVED` when signal arrives
   - Shows `NO DATA` when there is no recent signal

## Communication method used
Because Raspberry Pi 5 is not normally used as a direct USB peripheral for custom Android app traffic, this package uses:

**USB cable + Android USB tethering + HTTP communication**

That keeps your phone and Raspberry Pi connected through USB while remaining practical to implement.
